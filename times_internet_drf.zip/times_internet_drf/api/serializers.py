from rest_framework import serializers
from . import models


class ApiSerializer(serializers.ModelSerializer):

    class Meta:
        fields = ('id', 'name', 'parent', 'is_featured', 'image','is_active','description')
        model = models.Api


class BuildingSerializer(serializers.ModelSerializer):
    class Meta:
        fields = ('id', 'name', 'parent', 'is_featured', 'image','is_active','description')

        model = models.Api


    def __init__(self, *args, **kwargs):

        super(BuildingSerializer, self).__init__(*args, **kwargs)
        request = self.context.get("request")
        if request and request.query_params.get('fields'):
            fields = request.query_params.get('fields')
            if fields:
                fields = fields.split(',')
                existing = set(self.fields.keys())
                for field_name in existing - set(fields):
                    self.fields.pop(field_name)
