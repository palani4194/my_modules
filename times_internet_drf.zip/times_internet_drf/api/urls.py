from django.urls import path

from . import views

urlpatterns = [
    path('', views.ApiList.as_view()),
    path('<int:pk>/', views.ApiDetail.as_view()),
    path('create/', views.ApiCreateAPIView.as_view(), name='create'),

    # path('', views.BuildingView.as_view()),


]
