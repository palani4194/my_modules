
from django.db import models

class Api(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=50)
    parent = models.CharField(max_length=50)
    is_featured = models.BooleanField()
    image = models.ImageField()
    is_active = models.BooleanField()
    description = models.TextField()

    def __str__(self):
        return self.name
