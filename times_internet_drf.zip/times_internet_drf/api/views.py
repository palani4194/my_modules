from django.shortcuts import render
from rest_framework import viewsets
from rest_framework import generics
from .models import Api
from .serializers import ApiSerializer,BuildingSerializer
from django.db.models import Q
# from urllib import request

class ApiCreateAPIView(generics.CreateAPIView):
    queryset = Api.objects.all()
    serializer_class = ApiSerializer
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class ApiList(generics.ListAPIView):
    queryset = Api.objects.all()
    serializer_class = ApiSerializer

    search_fields = ('id', 'name')
    serializer_class = BuildingSerializer

    def get_queryset(self,*args,**kwargs,):
        # import ipdb; ipdb.set_trace()
        queryset = Api.objects.all()
        # query = self.request.GET.get("params")
        # if query:
        #     query_set_list = query_set_list.filter(
        #     Q(id__icontains=query)|
        #     Q(name__icontains=query)|
        #     Q(is_featured__icontains=query)).distinct()

        id = self.request.query_params.get('id', None)
        if id is not None:
            queryset = queryset.filter(id=id)

        return queryset

class ApiDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Api.objects.all()
    serializer_class = ApiSerializer
